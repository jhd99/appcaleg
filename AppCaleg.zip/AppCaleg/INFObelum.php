<div class="card">
	<div class="card-header">
		<div class="row mb-2">
			<div class="col-sm-8">
				<h2 class="m-0">Info SIMPATISAN (BELUM MEMILIH)</h2>
			</div>
			<div class="col-sm-4">
				<a href="EXPORTbelum.php" class="btn btn-info float-sm-right" target="_blank"> Export Data</a>
			</div>
		</div>
	</div>
	<!-- /.card-header -->
	<div class="card-body">
		<table id="example2" class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>NO</th>
					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>KECAMATAN</th>
					<th>STATUS</th>
					<th>RELAWAN</th>
					<th>NO. TPS</th>
					<th>ALAMAT TPS</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				include "_db.php";
				$no = 1 ;
				$query = "SELECT * FROM tb_penduduk WHERE STATUS_SIMPATISAN = 'BELUM MEMILIH' ";
				$sql = mysqli_query($result_sql, $query); 
				while($data = mysqli_fetch_array($sql)){
					echo "<tr>";
					echo "<td>".$no++."</td>";
					echo "<td>".$data['NIK']."</td>";
					echo "<td>".strtoupper($data['NAMA'])."</td>";
					echo "<td>".strtoupper($data['ALAMAT'])."</td>";
					echo "<td>".$data['RT_RW']."</td>";
					echo "<td>".$data['KEL_DESA']."</td>";
					echo "<td>".$data['KEC']."</td>";
					echo "<td>".$data['STATUS_SIMPATISAN']."</td>";
					echo "<td>".$data['RELAWAN']."</td>";
					echo "<td>".$data['NO_TPS']."</td>";
					echo "<td>".$data['ALAMAT_TPS']."</td>";
					echo "</tr>";
				}
				?>
			</tbody>
			<tfoot>
				<tr>
					<th>NO</th>
					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>KECAMATAN</th>
					<th>STATUS</th>
					<th>RELAWAN</th>
					<th>NO. TPS</th>
					<th>ALAMAT TPS</th>
				</tr>
			</tfoot>
		</table>
	</div>
</div>