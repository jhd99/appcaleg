<?php
session_start();
if (!isset($_SESSION['iusername'])) {
  header('Location:login.php');
  exit();
}
include "_db.php";
$NIK = @$_GET['NIK'];
$query = " SELECT * FROM tb_penduduk WHERE NIK='".$NIK."' ";
$sql = mysqli_query($result_sql, $query);
$data = mysqli_fetch_array($sql); 
?>
<div class="card card-secondary">
	<div class="card-header">
		<h3 class="card-title">Ubah STATUS SIMPATISAN / Pendukung Caleg 2024</h3>
	</div>
	<form action="MonitorUPDATE_proses.php?NIK=<?php echo $NIK;?>" class="" enctype="multipart/form-data" method="POST">
		<div class="card-body">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="#">NIK</label>
						<input type="text" class="form-control" id="NIK" name="NIK" value="<?php echo $data['NIK'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">NAMA</label>
						<input type="text" class="form-control" id="NAMA" name="NAMA" value="<?php echo $data['NAMA'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">ALAMAT</label>
						<input type="text" class="form-control" id="ALAMAT" name="ALAMAT" value="<?php echo $data['ALAMAT'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">RT / RW</label>
						<input type="text" class="form-control" id="RT_RW" name="RT_RW"  value="<?php echo $data['RT_RW'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">KELURAHAN/DESA</label>
						<input type="text" class="form-control" id="KEL_DESA" name="KEL_DESA"  value="<?php echo $data['KEL_DESA'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">RELAWAN / TIM PENCARI SIMPATISAN</label>
						<input type="text" class="form-control" id="RELAWAN" name="RELAWAN"  value="<?php echo $data['RELAWAN'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">NO. TPS</label>
						<input type="text" class="form-control" id="NO_TPS" name="NO_TPS" value="<?php echo $data['NO_TPS'];?>" readonly>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="#">ALAMAT TPS</label>
						<input type="text" class="form-control" id="ALAMAT_TPS" name="ALAMAT_TPS" value="<?php echo $data['ALAMAT_TPS'];?>" readonly>
					</div>
					<div class="form-group">
						<label for="#">STATUS SIMPATISAN</label>
						<input type="text" class="form-control btn btn-danger" value="<?php echo $data['STATUS_SIMPATISAN'];?>"  >
					</div>
					<div class="form-group">
						<label for="#">UBAH STATUS SIMPATISAN</label>
						<select name="STATUS_SIMPATISAN" id="STATUS_SIMPATISAN" class="form-control select2bs4" style="width: 100%;" required>
							<option selected="selected"> </option>
							<option value="SUDAH MEMILIH">SUDAH MEMILIH</option>                  
						</select>
					</div>
					<div class="form-group">
						<label for="#" class="col-sm-4 control-label">UPLOAD BUKTI COBLOS</label>
						<div class="col-sm-8">
							<div class="input-group">        
								<?php
								echo "<img src='gambar/bukti/$data[BUKTI_COBLOS]' height=100px width=200px >";
								?>
							</div>
							<br>
							<div class="input-group">
								<input type="checkbox" name="ubah_foto" value="true"><span>&nbsp;&nbsp;&nbsp; Ceklis Untuk Upload Bukti &nbsp;&nbsp;&nbsp; </span>
								<input name="BUKTI_COBLOS" type="file" accept=".jpg , .png"/>
							</div>
						</div>
					</div>
				</div>
			</div>	
			<div class="card-footer">
				<button type="submit" class="btn btn-success col-md-1">PROSES</button> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="reset" class="btn btn-secondary col-md-1 pull-right" value="BATAL">                    
			</div>
		</div>
	</form>
</div>