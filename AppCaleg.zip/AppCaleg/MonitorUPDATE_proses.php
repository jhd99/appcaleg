<?php
include "_db.php";
$NIK = @$_GET['NIK'];
$STATUS_SIMPATISAN = @$_POST['STATUS_SIMPATISAN'];

if(isset($_POST['ubah_foto'])){ 
	$foto = explode(".", @$_FILES["BUKTI_COBLOS"]["name"]);
	$tmp = @$_FILES['BUKTI_COBLOS']['tmp_name'];
	$fotobaru = round(microtime(true)) . '.' . end($foto);
	$path = "gambar/bukti/".$fotobaru; 
	if ($_FILES["BUKTI_COBLOS"]["size"] > 2000000) {
		echo '<script LANGUAGE="JavaScript">
		alert("MAAF UKURAN FILE TIDAK BOLEH LEBIH DARI 2MB")
		window.location.href="index.php?page=Msimpatisan";
		</script>';
	} else{
		if(move_uploaded_file($tmp, $path)){ 
			$query = "SELECT * FROM tb_penduduk WHERE NIK='".$NIK."'";
			$sql = mysqli_query($result_sql, $query); 
			$data = mysqli_fetch_array($sql); 
			if(is_file("gambar/bukti/".$data['BUKTI_COBLOS'])) 
				unlink("gambar/bukti/".$data['BUKTI_COBLOS']); 
			$query = "UPDATE tb_penduduk SET STATUS_SIMPATISAN='".$STATUS_SIMPATISAN."', BUKTI_COBLOS='".$fotobaru."' WHERE NIK='".$NIK."'";
			$sql = mysqli_query($result_sql, $query); 
			if($sql){ 
				echo '<script LANGUAGE="JavaScript">
				alert("DATA BERHASIL UPDATE")
				window.location.href="index.php?page=Monitorsimpatisan";
				</script>';
			}else{     
				echo '<script LANGUAGE="JavaScript">
				alert("UPDATE GAGAL")
				window.location.href="index.php?page=Monitorsimpatisan";
				</script>';
			}
		}else{
			echo '<script LANGUAGE="JavaScript">
			alert("UPDATE GAGAL")
			window.location.href="index.php?page=Monitorsimpatisan";
			</script>';
		}
	}
}else{
	$query = "UPDATE tb_penduduk SET STATUS_SIMPATISAN='".$STATUS_SIMPATISAN."' WHERE NIK='".$NIK."'";
	$sql = mysqli_query($result_sql, $query);
	if($sql){ 
		header("location:index.php?page=Monitorsimpatisan");
	}else{
		echo '<script LANGUAGE="JavaScript">
		alert("UPDATE GAGAL")
		window.location.href="index.php?page=Monitorsimpatisan";
		</script>';
	}
}
?>