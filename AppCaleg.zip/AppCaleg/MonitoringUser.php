<div class="card card-secondary">
	<div class="card-header">
		<h3 class="card-title">Form Tambah User APLIKASI PEMILU</h3>
	</div>
	<form action="MonitoringUser_addform.php" class="" enctype="multipart/form-data" method="POST">
		<div class="card-body">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="#">LEVEL USER</label>
						<select name="level_user" id="level_user" class="form-control select2bs4" style="width: 100%;" required>
							<option selected="selected"> </option>
							<option value="ADMIN">ADMIN</option>
							<option value="OPERATOR">OPERATOR (TIM PENCARI SIMPATISAN)</option>                  
						</select>
					</div>
					<div class="form-group">
						<label for="#">NAMA</label>
						<input type="text" class="form-control" id="nama_user" name="nama_user"  required>
					</div>
				</div>

				<div class="col-md-6">
					<div class="form-group">
						<label for="#">USERNAME</label>
						<input type="text" class="form-control" id="username" name="username" required placeholder="Untuk Login Aplikasi">
					</div>
					<div class="form-group">
						<label for="#">PASSWORD</label>
						<input type="password" class="form-control" id="password" name="password" required placeholder="Untuk Login Aplikasi">
					</div>
				</div>
			</div>
			<div class="card-footer">
				<button type="submit" class="btn btn-success col-md-1">PROSES</button> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="reset" class="btn btn-secondary col-md-1 pull-right" value="BATAL">                    
			</div>
			
		</form>
	</div>
	<div class="card">
		<div class="card-header">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h2 class="m-0">DAFTAR NAMA USER APLIKASI PEMILU</h2>
				</div>
				<div class="col-sm-6">
					
				</div>
			</div>
		</div>
		<!-- /.card-header -->
		<div class="card-body">
			<table id="example2" class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>NO</th>
						<th>NAMA</th>
						<th>USERNAME</th>
						<th>PASSWORD</th>
						<th>LEVEL</th>
						<th>LOGIN TIME</th>
						<th class="text-center">AKSI</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					include "_db.php";
					$NO = 1 ;
					$query = "SELECT * FROM tb_user WHERE level_user != 'PIMPINAN' ";
					$sql = mysqli_query($result_sql, $query); 
					while($data = mysqli_fetch_array($sql)){
						echo "<tr>";
						echo "<td>".$NO++."</td>";
						echo "<td>".strtoupper($data['nama_user'])."</td>";
						echo "<td>".strtoupper($data['username'])."</td>";
						echo "<td>".md5($data['password'])."</td>";
						echo "<td>".$data['level_user']."</td>";
						echo "<td>".$data['login_terakhir']."</td>";
						echo "<td align='center'>
						<button type='button' class='btn btn-default dropdown-toggle dropdown-icon' data-toggle='dropdown'>
						<span class='sr-only'>Toggle Dropdown</span>
						</button>
						<div class='dropdown-menu' role='menu'>

						<a class='dropdown-item' href='#ubah_modaluser' data-toggle='modal' data-id_user=".$data['id_user']."> <i class='nav-icon fas fa-edit'> </i>&nbsp;&nbsp;  UBAH</a>

						<div class='dropdown-divider'></div>
						<a class='dropdown-item' href='#' onClick='user_delete(\"MonitoringUser_hapus.php?id_user=$data[id_user]\")'><i class='nav-icon fas fa-trash'> </i>&nbsp;&nbsp;&nbsp; HAPUS</a>
						</div>
						</td>";
						echo "</tr>";
					}
					?>
				</tbody>
				<tfoot>
					<tr>
						<th>NO</th>
						<th>NAMA</th>
						<th>USERNAME</th>
						<th>PASSWORD</th>
						<th>LEVEL</th>
						<th>LOGIN TIME</th>
						<th class="text-center">AKSI</th>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
	<!-- HAPUS DATA -->
	<div class="modal modal-danger fade" id="hapus_modaluser">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Ingin Hapus Data USER</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                 
				</div>
				<div class="modal-body">
					<p>Silahkan Lanjutkan dengan Konfirmasi "HAPUS" &hellip;</p>
				</div> 
				<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
					<a href="#" class="btn btn-danger" id="delete_link"> HAPUS</a>
					<button type="button" class="btn btn-default" data-dismiss="modal"> BATAL</button>
				</div>
			</div>
		</div>
	</div>
	<!-- EDIT DATA -->
<div class="modal fade" id="ubah_modaluser">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Ubah Level User</h4>
        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-default">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="hasil-data"></div>
      </div>
    </div>
  </div>
</div>

