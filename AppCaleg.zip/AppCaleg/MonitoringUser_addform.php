<?php
include "_db.php";
$nama_user = htmlspecialchars($_POST['nama_user']);
$username = htmlspecialchars($_POST['username']);
$password = htmlspecialchars($_POST['password']);
$level_user = htmlspecialchars($_POST['level_user']);

$query = "SELECT * FROM tb_user WHERE username = '".$username."'";
$result = mysqli_query($result_sql, $query);

if(mysqli_num_rows($result) > 0) {
  // NIK value already exists in the table, show error message
  echo '<script LANGUAGE="JavaScript">
  alert("MAAF USERNAME SUDAH TERDAFTAR")
  window.location.href="index.php?page=MonitoringUser";
  </script>';
} else {
  $query = "INSERT INTO tb_user (nama_user, username, password, level_user) VALUES ('".$nama_user."','".$username."','".$password."','".$level_user."')";
    $sql = mysqli_query($result_sql, $query); 
    if($sql){ 
      echo '<script LANGUAGE="JavaScript">
      alert("BERHASIL")
      window.location.href="index.php?page=MonitoringUser";
      </script>';
    }else{
      echo '<script LANGUAGE="JavaScript">
      alert("GAGAL")
      window.location.href="index.php?page=MonitoringUser";
      </script>';
    }
  }
?>