<?php

include "_db.php";

$id_user = @$_GET["id_user"];

if($delete = mysqli_query ($result_sql, "DELETE FROM tb_user WHERE id_user='$id_user'")){
	header("Location:index.php?page=MonitoringUser");
	exit();
}
die ("Terdapat Kesalahan : ".mysqli_error($result_sql));

?>