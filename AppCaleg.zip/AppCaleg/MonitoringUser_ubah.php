<?php
include "_db.php";
if(@$_POST['idx']) {
	$id_user = @$_POST['idx'];      
	$query = mysqli_query($result_sql, "SELECT * FROM tb_user WHERE id_user='$id_user'");
	if($query == false){
		die ("Gagal !". mysqli_error($result_sql));
	}
	while($data = mysqli_fetch_array($query)) {
		?>
		<form action="MonitoringUser_ubahproses.php" name="modal_popup" enctype="multipart/form-data" method="post">

			<div class="form-group">
				<input type="hidden"  name="id_user" value="<?php echo $data["id_user"];?>" class="form-control" readonly>        
			</div> 

			<div class="form-group">
				<label for="#">NAMA</label>
				<input type="text" class="form-control" value="<?php echo $data["nama_user"];?>" readonly>
			</div>
			<div class="form-group">
				<label for="#">LEVEL</label>
				<input type="text" class="form-control" value="<?php echo $data["level_user"];?>" readonly>
			</div>
			<div class="form-group">
				<label for="#">PILIH LEVEL BARU</label>
				<select name="level_user" id="level_user" class="form-control select2bs4" style="width: 100%;" required>
					<option selected="selected"> </option>
					<option value="ADMIN">ADMIN</option>
					<option value="OPERATOR">OPERATOR (TIM PENCARI SIMPATISAN)</option>                  
				</select>
			</div>

			<div class="modal-footer">
				<button type="submit" class="btn btn-success"> PROSES</button>
				<button type="button" class="btn btn-default" data-dismiss="modal"> BATAL</button>
				
			</div>
		</form>     
		<?php } } ?>