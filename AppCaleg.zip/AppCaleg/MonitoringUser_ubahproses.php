<?php
include "_db.php";
$id_user = @$_POST['id_user'];
$level_user = @$_POST['level_user'];

if ($query = mysqli_query($result_sql, "UPDATE tb_user SET level_user='$level_user' WHERE id_user='$id_user'")){
	header("Location:index.php?page=MonitoringUser");
	exit();
} 
die ("Terdapat kesalahan : ". mysqli_error($result_sql));
?>

