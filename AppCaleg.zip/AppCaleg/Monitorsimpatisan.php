<div class="card">
	<div class="card-header">
		<div class="row mb-2">
			<div class="col-sm-8">
				<h2 class="m-0">Monitoring STATUS SIMPATISAN / Pendukung Caleg 2024</h2>
			</div>
			<div class="col-sm-4">
				
			</div>
		</div>
	</div>
	<!-- /.card-header -->
	<div class="card-body">
		<table id="example2" class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>STATUS</th>
					<th class="text-center">AKSI</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				include "_db.php";
				$query = " SELECT * FROM tb_penduduk WHERE STATUS_SIMPATISAN = 'BELUM MEMILIH' ";
				$sql = mysqli_query($result_sql, $query); 
				while($data = mysqli_fetch_array($sql)){
					echo "<tr>";
					echo "<td>".$data['NIK']."</td>";
					echo "<td>".strtoupper($data['NAMA'])."</td>";
					echo "<td>".strtoupper($data['ALAMAT'])."</td>";
					echo "<td>".$data['RT_RW']."</td>";
					echo "<td>".$data['KEL_DESA']."</td>";
					echo "<td>".$data['STATUS_SIMPATISAN']."</td>";
					echo "<td align='center'>
					<a href='?page=MonitorUPDATE&NIK=$data[NIK]' class='btn btn-info btn-sm' title='UBAH STATUS'> UBAH STATUS</a>
					</td>";
					echo "</tr>";
				}
				?>
			</tbody>
			<tfoot>
				<tr>
					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>STATUS</th>
					<th class="text-center">AKSI</th>
				</tr>
			</tfoot>
		</table>
	</div>
</div>