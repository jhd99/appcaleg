<div class="card card-secondary">
	<div class="card-header">
		<h3 class="card-title">Form Tambah Data SIMPATISAN / Pendukung Caleg 2024</h3>
	</div>
	<form action="simpatisan_addform.php" class="" enctype="multipart/form-data" method="POST">
		<div class="card-body">
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="#">NIK</label>
						<input type="text" class="form-control" id="NIK" name="NIK"  required>
					</div>
					<div class="form-group">
						<label for="#">NAMA</label>
						<input type="text" class="form-control" id="NAMA" name="NAMA"  required>
					</div>
					<div class="form-group">
						<label for="#">ALAMAT</label>
						<input type="text" class="form-control" id="ALAMAT" name="ALAMAT"  required>
					</div>
					<div class="form-group">
						<label for="#">RT / RW</label>
						<input type="text" class="form-control" id="RT_RW" name="RT_RW"  required>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="#">KELURAHAN/DESA</label>
						<input type="text" class="form-control" id="KEL_DESA" name="KEL_DESA"  required>
					</div>
					<div class="form-group">
						<label for="#">KECAMATAN</label>
						<input type="text" class="form-control" id="KEC" name="KEC"  required>
					</div>
					<div class="form-group">
						<label for="#">RELAWAN / TIM PENCARI SIMPATISAN</label>
						<input type="text" class="form-control" id="RELAWAN" name="RELAWAN"  required>
					</div>
					<div class="form-group">
						<label for="#">NO. TPS</label>
						<input type="text" class="form-control" id="NO_TPS" name="NO_TPS">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="#">ALAMAT TPS</label>
						<input type="text" class="form-control" id="ALAMAT_TPS" name="ALAMAT_TPS">
					</div>
					<div class="form-group">
						<label for="#" class="col-sm-4 control-label">FOTO KTP</label>
						<div class="col-sm-10">
							<div class="input-group">        
								<input name="FOTO_KTP" id="FOTO_KTP" type="file" accept=".jpg , .png"/>
							</div>
						</div>
					</div>
					<div class="form-group">
						<input type="hidden" class="form-control" id="STATUS_SIMPATISAN" name="STATUS_SIMPATISAN" value="BELUM MEMILIH">
					</div>
				</div>
			</div>
			<div class="card-footer">
				<button type="submit" class="btn btn-success col-md-1">PROSES</button> 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="reset" class="btn btn-secondary col-md-1 pull-right" value="BATAL">                    
			</div>
		</div>
	</form>
</div>
<div class="card">
	<div class="card-header">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h2 class="m-0">DAFTAR NAMA SIMPATISAN CALEG 2024</h2>
			</div>
			<div class="col-sm-6">
				
			</div>
		</div>
	</div>
	<!-- /.card-header -->
	<div class="card-body">
		<table id="example2" class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>KECAMATAN</th>
					<th>STATUS</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				include "_db.php";
				$query = "SELECT * FROM tb_penduduk";
				$sql = mysqli_query($result_sql, $query); 
				while($data = mysqli_fetch_array($sql)){
					echo "<tr>";
					echo "<td>".$data['NIK']."</td>";
					echo "<td>".strtoupper($data['NAMA'])."</td>";
					echo "<td>".strtoupper($data['ALAMAT'])."</td>";
					echo "<td>".$data['RT_RW']."</td>";
					echo "<td>".$data['KEL_DESA']."</td>";
					echo "<td>".$data['KEC']."</td>";
					echo "<td><button class='btn btn-danger btn-sm'>".$data['STATUS_SIMPATISAN']."</button></td>";
					echo "</tr>";
				}
				?>
			</tbody>
			<tfoot>
				<tr>

					<th>NIK</th>
					<th>NAMA</th>
					<th>ALAMAT</th>
					<th>RT/RW</th>
					<th>KEL/DESA</th>
					<th>KECAMATAN</th>
					<th>STATUS</th>
				</tr>
			</tfoot>
		</table>
	</div>
</div>