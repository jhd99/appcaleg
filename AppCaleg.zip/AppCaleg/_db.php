<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "db_caleg"; 
$result_sql = mysqli_connect($host, $username, $password, $database); 
?>