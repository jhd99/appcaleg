<?php 
	include_once('_db.php');
	$username = isset($_POST['username']) ? $_POST['username'] : '';
	$password = isset($_POST['password']) ? $_POST['password'] : '';
	$exist = '';
	$rule = '';

	$sql = "SELECT count(username) as c, level_user from tb_user WHERE username = '".$username."' and password='".$password."' ";
	$result= mysqli_query($result_sql, $sql) or die(mysqli_error($result_sql));
	if($result){
	    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
	    	$exist = $row["c"];
	    	$rule=$row["level_user"];
	    }
	}
	if($exist>0){
		$sql = "update tb_user set login_terakhir=now() where username = '".$username."' and password='".$password."'";
		$result= mysqli_query($result_sql, $sql) or die(mysqli_error($result_sql));
		session_start();
		$_SESSION['iusername']  = $username;
		$_SESSION['irule']  	= $rule;
		echo "Success";
	}
?>