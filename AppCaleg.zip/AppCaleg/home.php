<div class="col-md-12">
	<!-- Widget: user widget style 1 -->
	<div class="card card-widget widget-user">
		<!-- Add the bg color to the header using any of the bg-* classes -->
		<div class="widget-user-header bg-info">
			<h3 class="widget-user-username"> Maulana Adi Wijaya </h3>
			<h5 class="widget-user-desc">Founder & CEO</h5>
		</div>
		<div class="widget-user-image">
			<img class="img-circle elevation-2" src="dist/img/user1-128x128.jpg" alt="User Avatar">
		</div>
		<div class="card-footer">
			<div class="row">
				<div class="col-sm-6 border-right">
					<div class="description-block">
						<div class="small-box bg-default">
							<div class="inner">

								<?php
								include "_db.php";
								$status = "BELUM MEMILIH"; 
								$query = mysqli_query($result_sql, "SELECT COUNT(*) as total FROM tb_penduduk WHERE STATUS_SIMPATISAN='$status'");
								$row = mysqli_fetch_assoc($query);
								$total = $row['total'];
								echo "<h3>".$total."</h3>";
								echo "<p>".$status."</p>" ;
								?>

							</div>
							<div class="icon">
								<i class="fas fa-chart-pie"></i>
							</div>
						</div>
					</div>
					<!-- /.description-block -->
				</div>
				<!-- /.col -->
				<div class="col-sm-6">
					<div class="description-block">
						<div class="small-box bg-default">
							<div class="inner">
								<?php
								$status2 = "SUDAH MEMILIH"; 
								$query2 = mysqli_query($result_sql, "SELECT COUNT(*) as total2 FROM tb_penduduk WHERE STATUS_SIMPATISAN='$status2'");
								$row = mysqli_fetch_assoc($query2);
								$total2 = $row['total2'];
								echo "<h3>".$total2."</h3>";
								echo "<p>".$status2."</p>" ;
								?>
							</div>
							<div class="icon">
								<i class="fas fa-chart-pie"></i>
							</div>
						</div>
					</div>
					<!-- /.description-block -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</div>
	</div>
	<!-- /.widget-user -->
</div>








